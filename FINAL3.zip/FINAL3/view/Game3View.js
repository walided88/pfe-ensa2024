import React, { useState, useCallback } from 'react';
import { StyleSheet, View, Animated, TouchableWithoutFeedback, SafeAreaView, Dimensions, Text, TouchableOpacity } from 'react-native';
import { GameEngine } from 'react-native-game-engine';
import FastImage from 'react-native-fast-image';
import Obstacle from '../systems/Obstacle';
import MusicPlayer from '../components/MusicPlayer';
import * as Animatable from 'react-native-animatable';
import GameComponent from '../components/GeminiHelper'; // Assurez-vous que le chemin est correct
import { useDispatch, useSelector } from 'react-redux';
import { setShow,setReturn } from '../redux/actions';

const { width, height } = Dimensions.get('window');

const GameView = ({ navigation, handleTouch, animatedStyle, imageSource, box, world }) => {
  const onHandleTouch = useCallback(handleTouch, [handleTouch]);
  const navigateToGemini = useCallback(() => navigation.navigate('Gemini'), [navigation]);
  const dispatch = useDispatch();
  const isShow = useSelector((state) => state.isShowing);
  console.log(`isShow cccccccccccccsdssss`,isShow);

  const handleShow = () => {

    dispatch(setShow(true));


  };
  console.log(`isShow cccccccccccccsdssss`,isShow);

  const handleHide = () => {
    setShowGameComponent(false);
  };

  return (
    <TouchableWithoutFeedback onPress={onHandleTouch}>
      <View style={styles.container}>
        <GameEngine 
          style={styles.gameContainer} 
          systems={[]} 
          entities={{
            box: { body: box, size: [width * 0.1, height * 0.4], renderer: () => null }
          }}
        >
          
          <Animated.View style={[styles.animatedBox, animatedStyle]}>
            <FastImage
              style={{ width: width * 0.1, height: height * 0.4 }}
              source={imageSource}
              resizeMode={FastImage.resizeMode.contain}
            />

<Animatable.View animation="pulse" iterationCount="infinite">
              <TouchableOpacity onPress={handleShow} style={styles.helpButton}>
                <Text style={styles.helpButtonText}>HELP?</Text>
              </TouchableOpacity>
            </Animatable.View>
          </Animated.View>
          <Obstacle 
            world={world} 
            position={{ x: width * 0.25, y: height * 0.2 }} 
            size={{ width: width * 0.5, height: height * 0.02 }} 
            angle={(Math.PI / 4) * 2.6} 
          />
          <Obstacle 
            world={world} 
            position={{ x: width * 0.72, y: height * 0.2 }} 
            size={{ width: width * 0.6, height: height * 0.02 }} 
            angle={(Math.PI / 4) * 1.34} 
          />
          <Obstacle 
            world={world} 
            position={{ x: width * 0.6, y: height * 0.03 }} 
            size={{ width: width * 0.6, height: height * 0.02 }} 
            angle={(Math.PI / 2) * 0.001} 
          />
        </GameEngine>
        <SafeAreaView style={styles.container}>
          <MusicPlayer file="running3.mp3" volume={0.9} />
        </SafeAreaView>
      </View>
    </TouchableWithoutFeedback>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  gameContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
  },
  animatedBox: {
    width: 50,
    height: 50,
    position: 'absolute',
  },
  helpButton: {
    position: 'absolute',
    width: width * 0.1,
    height: height * 0.1,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'grey',
    borderRadius: 111,
    justifyContent: 'center',
    alignItems: 'center',
    top: -height * 0.5,
    right: -width * 0.1,
  },
  helpButtonText: {
    color: '#007BFF',
    fontSize: 15,
    textAlign: 'center',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    padding: 10,
    backgroundColor: 'red',
    borderRadius: 5,
  },
  closeButtonText: {
    color: 'white',
    fontSize: 16,
  },
});

export default GameView;
