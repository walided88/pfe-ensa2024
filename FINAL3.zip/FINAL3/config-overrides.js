const { override, addWebpackAlias } = require('customize-cra');
const path = require('path');

module.exports = override(
  addWebpackAlias({
    'react-native': 'react-native-web',
    'react-native/Libraries/Image/resolveAssetSource': 'react-native-web/dist/modules/AssetRegistry'
  })
);
