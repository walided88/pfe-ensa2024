import React, { useState, useCallback, useEffect, useRef } from 'react';
import { View, Animated, ImageBackground, Dimensions, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Matter from 'matter-js';
import Game from '../components/Character1';
import MovingImage from '../systems/MovingImage';
import { setAddition } from '../store/actions';
import BgMusic from "../components/BgMusique";
import { incrementScoreAddition } from '../services/Database';
import * as Animatable from 'react-native-animatable';
import { setShow,setReturn } from '../store/actions';
import _ from 'lodash';

const { width, height } = Dimensions.get('window');

const imagesArray = [
  require('../assets/images/1PREP.webp'),
  require('../assets/images/2PREP.webp'),
  require('../assets/images/3PREP.webp'),
  require('../assets/images/4PREP.webp'),
  require('../assets/images/6PREP.webp'),
];

const randomImagesArray = [
  require('../assets/images/1PASK.webp'),
  require('../assets/images/2PASK.webp'),
  require('../assets/images/3PASK.webp'),
  require('../assets/images/4PASK.webp'),
  require('../assets/images/6PASK.webp'),
];

const initialPositions = [
  { x: width * 0.55, y: height * 0.2 },
  { x: width * 0.4, y: height * 0.14 },
  { x: width * 0.3, y: height * 0.4 },
  { x: width * 0.66, y: height * 0.151 },
  { x: width * 0.73, y: height * 0.4 },
];

const finalPositions = [
  { x: width * 0.4, y: height * 0.4 },
  { x: width * 0.4, y: height * 0.4 },
  { x: width * 0.4, y: height * 0.4 },
  { x: width * 0.1, y: height * 0.1 },
  { x: width * 0.1, y: height * 0.1 },
];

const characterDimensions = {
  width: width * 0.4,
  height: height * 3,
};

const initialCharacterPosition = { x: width * 0.4, y: height * 0.4 };

const congratulationImage = require('../assets/images/congratulations.png');
const scoreImages = [
  require('../assets/images/0.webp'),
  require('../assets/images/1.webp'),
  require('../assets/images/2.webp'),
  require('../assets/images/3.webp'),
  require('../assets/images/4.webp'),
  require('../assets/images/5.webp'),
  require('../assets/images/6.webp'),
];

/**
 * GameScreen est un composant React Native qui affiche un écran de jeu avec des images animées, un personnage, et un système de score.
 * Le jeu intègre des fonctionnalités de Matter.js pour la gestion physique des objets, ainsi qu'un système de navigation entre différents écrans.
 * 
 * @param {Object} props Les propriétés du composant.
 * @param {Object} props.navigation Objet de navigation utilisé pour naviguer entre les écrans.
 * @param {Object} props.animatedStyle Style animé appliqué à certains composants.
 * @param {boolean} props.showGameComponent Indicateur pour afficher ou cacher des composants spécifiques du jeu.
 * @returns {JSX.Element} Le composant GameScreen.
 */
const GameScreen = ({ navigation, animatedStyle, showGameComponent }) => {
  const dispatch = useDispatch();
  const characterPosition = useSelector((state) => state.position);
  const playerId = useSelector((state) => state.playerId); // Assurez-vous que playerId est correctement défini
  const isShow = useSelector((state) => state.isShowing);
  const retourX = useSelector((state) => state.retour);
  const [ordre, setOrdre] = useState(1);
  console.log(`retourX cccccccccccccsdssss`,retourX);

  const [addObj, setAddObj] = useState(0);
  const [images, setImages] = useState([]);
  const [randomImageIndex, setRandomImageIndex] = useState(null);
  const [showCongratulation, setShowCongratulation] = useState(false);
  const [currentScoreImage, setCurrentScoreImage] = useState(null);
  const engine = useRef(Matter.Engine.create({ enableSleeping: false }));
  const world = engine.current.world;
  const characterBody = useRef(null);
  const gameRef = useRef();
  const navigateToGemini = useCallback(() => navigation.navigate('Gemini'), [navigation]);
  const navigateToGame2 = useCallback(() => navigation.navigate('Game2'), [navigation]);

  /**
   * Initialise les images du jeu avec des positions et des sources aléatoires.
   * Utilise Lodash pour mélanger les positions initiales des images.
   */
  const initializeImages = () => {
    const shuffledImagesArray = imagesArray; // Tableau des images à afficher
    const shuffledPositionsArray = _.shuffle([...initialPositions]); // Utilisation de Lodash pour mélanger les positions
    const now = Date.now();
    const initialImages = shuffledPositionsArray.map((pos, i) => ({
      id: now + i,
      initialPosition: pos,
      finalPosition: finalPositions[i],
      imageSource: shuffledImagesArray[i],
      body: Matter.Bodies.rectangle(pos.x, pos.y, width * 0.1, height * 0.1, { isStatic: false }),
    }));
    setImages(initialImages);
    setRandomImageIndex(Math.floor(Math.random() * randomImagesArray.length)); // Sélectionne une image aléatoire

    initialImages.forEach(image => {
      Matter.World.add(world, image.body); // Ajoute les corps des images au monde de Matter.js
    });
  };

  /**
   * Redistribue les images après qu'une image a été retirée.
   */
  const redistributeImages = () => {
    setRandomImageIndex(Math.floor(Math.random() * randomImagesArray.length)); // Sélectionne une nouvelle image aléatoire
    if (gameRef.current) {
      gameRef.current.resetCharacterPosition(initialCharacterPosition.x, initialCharacterPosition.y); // Réinitialise la position du personnage
    }
    setShowCongratulation(false); // Cache l'image de félicitations
    initializeImages(); // Réinitialise les images
  };

  useEffect(() => {
    initializeImages(); // Initialise les images lors du montage du composant

    return () => {
      images.forEach(image => {
        Matter.World.remove(world, image.body); // Supprime les corps des images du monde de Matter.js lors du démontage du composant
      });
    };
  }, []);

  /**
   * Supprime une image du jeu.
   * 
   * @param {number} id Identifiant de l'image à supprimer.
   * @param {Object} body Corps Matter.js de l'image à supprimer.
   */
  const removeImage = useCallback((id, body) => {
    setImages((prevImages) => prevImages.filter((image) => image.id !== id)); // Supprime l'image de l'état local
    Matter.World.remove(world, body); // Supprime le corps de l'image du monde de Matter.js

    const imageIndex = images.findIndex(image => image.id === id);
    if (imageIndex === randomImageIndex) {
      redistributeImages(); // Redistribue les images si l'image retirée est l'image aléatoire
      setAddObj((prevAddObj) => prevAddObj + 1); // Incrémente le compteur d'objets ajoutés
    } else {
      redistributeImages(); // Redistribue les images
    }
  }, [world, randomImageIndex, images]);

  useEffect(() => {
    dispatch(setAddition(addObj)); // Met à jour le score dans Redux
  }, [addObj, dispatch]);

  useEffect(() => {
    if (playerId && addObj >= 5 && !showCongratulation) {
      incrementScoreAddition(playerId, 10, () => {
        console.log(`Score addition incremented by 10 for player ID ${playerId}`);
      });
      setShowCongratulation(true); // Affiche l'image de félicitations
    } else {
      setCurrentScoreImage(scoreImages[addObj % scoreImages.length]); // Met à jour l'image du score
    }
  }, [addObj, playerId, showCongratulation]);

  useEffect(() => {
    if (isShow) {
      navigateToGemini(); // Navigue vers l'écran "Gemini" si isShow est vrai
      dispatch(setReturn(1)); // Met à jour l'état Redux pour retourX
    }
  }, [isShow, navigateToGemini, retourX]);

  if (!characterPosition || characterPosition.x === undefined || characterPosition.y === undefined) {
    return <Text>Loading...</Text>; // Affiche un message de chargement si la position du personnage n'est pas encore définie
  }

  

  return (
    <ImageBackground source={require('../assets/images/kitchen1gaming.webp')} style={styles.background}>
      <View style={styles.container}>
        {randomImageIndex !== null && (
          <View style={styles.randomImageContainer}>
            <Image source={randomImagesArray[randomImageIndex]} style={styles.randomImage} />
          </View>
        )}

          <Animated.View style={[styles.animatedBox, animatedStyle]}>
          {isShow || (
            <Animatable.View animation="pulse" iterationCount="infinite">
              <TouchableOpacity onPress={navigateToGemini} style={styles.buttonText2}>
              </TouchableOpacity>
            </Animatable.View>
          )}
        </Animated.View>

        {images.map((image) => (
          <MovingImage
            key={image.id}
            initialPosition={image.initialPosition}
            finalPosition={image.finalPosition}
            imageSource={image.imageSource}
            characterPosition={characterPosition}
            characterDimensions={characterDimensions}
            onRemove={() => removeImage(image.id, image.body)}
            body={image.body}
          />
        ))}
        <Game ref={gameRef} />
        {showCongratulation && (
          <View style={styles.congratulationContainer}>
            <Image source={congratulationImage} style={styles.congratulationImage} />
            <Animatable.View>
              <TouchableOpacity style={styles.resultsButton} onPress={() => navigation.navigate('Results')}>
                <Text style={styles.buttonText}>RESULTATS</Text>
              </TouchableOpacity>
            </Animatable.View>
          </View>
        )}
        {currentScoreImage && (
          <View style={styles.scoreContainer}>
            <Image source={currentScoreImage} style={styles.scoreImage} />
          </View>
        )}
              
     
        <BgMusic musicFile="bg1.mp3" volume={0.3} />
      </View>
    </ImageBackground>
  );
};


// Styles pour le composant
const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
  },
  congratulationContainer: {
    position: 'absolute',
    top: height * 0.009,
    left: width * 0.27,
    zIndex: 3,
  },
  resultsButton: {
    position: 'absolute',
    bottom: -height * 0.02,
    right: -width * 0.29,
    backgroundColor: '#007BFF',
    padding: 22,
    borderRadius: 20,
    marginTop: 20,
    shadowOpacity: 0.8,
    elevation: 5,
    width: width * 0.22,
    height: height * 0.25,

  },
  buttonText: {
    color: '#FFF',
    fontSize: 20,
    color: 'white',
    padding: 15,
    


  },
  congratulationImage: {
    width: width * 0.4,
    height: height * 0.9,
  },
  scoreContainer: {
    position: 'absolute',
    top: height * 0.07,
    left: width * 0.03,
    zIndex: 3,
  },
  scoreImage: {
    width: width * 0.1,
    height: height * 0.25,
  },
  randomImageContainer: {
    position: 'absolute',
    top: height * 0.012,
    right: width * -0.37,
  },
  randomImage: {
    width: width,
    height: height,
    top: -height * 0.01,
    right: width * 0.37,
  },

  
});
export default GameScreen;
